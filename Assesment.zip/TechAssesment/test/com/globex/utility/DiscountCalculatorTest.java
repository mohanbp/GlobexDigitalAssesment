package com.globex.utility;

import static org.junit.Assert.*;

import java.math.BigDecimal;
import java.time.LocalDate;


import org.junit.Before;
import org.junit.Test;
import com.globex.entities.Customer;
import com.globex.entities.Employee;
import com.globex.entities.Product;
import com.globex.entities.User;
import com.globex.enums.ProductTypeEnum;



public class DiscountCalculatorTest {
	
	DiscountCalculator  discountCalculator = new DiscountCalculator();
	User user;
	Product product1;
	Product product2;

	@Before
    public void setUp() throws Exception {
		product1 = new Product();
	 	product1.setProductId(new BigDecimal(2.0));
	 	product1.setProductName("Book");
	 	product1.setProductType(ProductTypeEnum.PRODUCT_TYPE_STATIONERY);
	 	product1.setPrice(50);
	 	  
	 	product2 = new Product();
	 	product2.setProductId(new BigDecimal(3.0));
	 	product2.setProductName("Laptop");
	 	product2.setProductType(ProductTypeEnum.PRODUCT_TYPE_ELECTRONICS);
	 	product2.setPrice(50);    
	 	}
	
	
	    @Test
	    public void test_calculateDiscount_user_customer_type() {
	    	
	    	user = new User();
			user.setId(new BigDecimal(2.0));
			user.setUserName("Test");
		 	user.setUserType(new Customer().getUserType());
		 	user.setCreatedDate(LocalDate.of( 2010 , 1 , 1 ));
	    	assertEquals(47.5, (double)discountCalculator.calculateDiscount(user, product1),0);
	    }
	    
	    @Test
	    public void test_calculateDiscount_user_employee_type() {
	    	
	    	user = new User();
			user.setId(new BigDecimal(2.0));
			user.setUserName("Test");
		 	user.setUserType(new Employee().getUserType());
		 	user.setCreatedDate(LocalDate.of( 2010 , 1 , 1 ));
	    	assertEquals(35.0, (double)discountCalculator.calculateDiscount(user, product1),0);
		    }
	    
	    
	    @Test
	    public void test_calculateDiscount_user_affiliate_type() {
	    	user = new User();
			user.setId(new BigDecimal(2.0));
			user.setUserType(new Employee().getUserType());
		 	user.setCreatedDate(LocalDate.of( 2010 , 1 , 1 ));
	    	assertEquals(45.0, (double)discountCalculator.calculateDiscount(user, product1),0);
		    }

}
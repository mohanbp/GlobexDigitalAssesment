package com.globex.entities;

import java.math.BigDecimal;

import com.globex.enums.ProductTypeEnum;

public class Product {

	private BigDecimal productId;
	private String productName;
	private ProductTypeEnum productType;
	private double price;

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public BigDecimal getProductId() {
		return productId;
	}

	public ProductTypeEnum getProductType() {
		return productType;
	}

	public void setProductType(ProductTypeEnum productType) {
		this.productType = productType;
	}

	public void setProductId(BigDecimal productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

}

package com.globex.entities;

import com.globex.enums.UserTypeEnum;

public class Customer extends User {
	UserTypeEnum userType=UserTypeEnum.USER_TYPE_CUSTOMER;
	
	public UserTypeEnum getUserType() {
		return userType;
	}
}

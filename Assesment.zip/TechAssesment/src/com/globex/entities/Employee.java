package com.globex.entities;

import com.globex.enums.UserTypeEnum;

public class Employee extends User {
	UserTypeEnum	userType=UserTypeEnum.USER_TYPE_EMPLOYEE;
	
	public UserTypeEnum getUserType() {
		return userType;
	}
}

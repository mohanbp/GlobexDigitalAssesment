package com.globex.entities;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import com.globex.enums.UserTypeEnum;

public class User {

	private BigDecimal id;
	private String userName;
	public UserTypeEnum userType = UserTypeEnum.USER_TYPE_AFFILIATE;
	private LocalDate createdDate;

	public LocalDate getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}

	public BigDecimal getId() {
		return id;
	}

	public UserTypeEnum getUserType() {
		return userType;
	}

	public void setUserType(UserTypeEnum userType) {
		this.userType = userType;
	}

	public void setId(BigDecimal id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Order placeOrder(List<Product> products) {
		Order order = new Order();
		order.setProducts(products);
		return order;
	}

}

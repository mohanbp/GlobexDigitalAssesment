package com.globex.entities;

import java.math.BigInteger;
import java.util.List;

import com.globex.utility.DiscountCalculator;


public class Order {

	private BigInteger orderId;
	private List<Product> products;
	DiscountCalculator discountCalculator = new DiscountCalculator();

	public BigInteger getOrderId() {
		return orderId;
	}

	public void setOrderId(BigInteger orderId) {
		this.orderId = orderId;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	public Double generateBill(User user) {
		List<Product> products = this.products;
		Double totalOrderCost = 0.0;
		for (Product product : products) {
			double priceAfterDiscount = discountCalculator.calculateDiscount(user, product);
			System.out.println("discountedValue >>>>>  " + priceAfterDiscount);
			totalOrderCost = totalOrderCost + priceAfterDiscount;
		}

		return totalOrderCost;

	}

}

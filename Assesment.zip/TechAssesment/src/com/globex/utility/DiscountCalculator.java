package com.globex.utility;

import java.util.ArrayList;
import java.util.List;

import com.globex.entities.Product;
import com.globex.entities.User;
import com.globex.enums.ProductTypeEnum;
import com.globex.rules.IDiscountRule;
import com.globex.rules.LoyalCustomerDiscountRule;
import com.globex.rules.UserAsAffiliateDiscountRule;
import com.globex.rules.UserAsEmployeeDiscountRule;

public class DiscountCalculator {
	List<IDiscountRule> rules = new ArrayList<>();

	public DiscountCalculator() {
		rules.add(new LoyalCustomerDiscountRule());
		rules.add(new UserAsAffiliateDiscountRule());
		rules.add(new UserAsEmployeeDiscountRule());

	}

	public double calculateDiscount(User user, Product product) {
		boolean isRuleExecuted = false;
		Double discount = 0.0;
		for (IDiscountRule rule : rules) {
			if (!isRuleExecuted && product.getProductType() != ProductTypeEnum.PRODUCT_TYPE_GROCERY) {
				discount = rule.calculateDiscount(user, product);
			}
			if (rule.isRuleExecuted()) {
				isRuleExecuted = true;
			}
		}
		return discount;
	}

}

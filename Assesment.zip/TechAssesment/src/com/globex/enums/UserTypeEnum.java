package com.globex.enums;

public enum  UserTypeEnum {

	USER_TYPE_EMPLOYEE,USER_TYPE_AFFILIATE,USER_TYPE_CUSTOMER;
}

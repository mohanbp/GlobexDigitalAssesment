package com.globex.enums;

public enum ProductTypeEnum {
		PRODUCT_TYPE_GROCERY, PRODUCT_TYPE_ELECTRONICS, PRODUCT_TYPE_STATIONERY
}

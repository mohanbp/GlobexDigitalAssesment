package com.globex.rules;

import java.time.LocalDate;

import com.globex.entities.Product;
import com.globex.entities.User;
import com.globex.enums.UserTypeEnum;

public class LoyalCustomerDiscountRule implements IDiscountRule {

	private double discountPercentage = 0.05;

	public boolean ruleExecutonStatus;

	@Override
	public Double calculateDiscount(User user, Product product) {
		Double discountedValue = 0.0;
		if (user.getUserType() == UserTypeEnum.USER_TYPE_CUSTOMER) {
			long yearDiff = java.time.temporal.ChronoUnit.YEARS.between(user.getCreatedDate(), LocalDate.now());
			System.out.println("yearDiff in customer rule >>>> " + yearDiff);
			if (yearDiff > 2) {
				ruleExecutonStatus = true;
				discountedValue = product.getPrice() - product.getPrice() * discountPercentage;
			}
		}
		return discountedValue;
	}

	public boolean isRuleExecuted() {
		return ruleExecutonStatus;
	}

}

package com.globex.rules;

import java.math.BigDecimal;
import com.globex.entities.Product;
import com.globex.entities.User;

public interface IDiscountRule {
    public boolean isRuleExecuted();
	public Double calculateDiscount(User user,Product product);
}

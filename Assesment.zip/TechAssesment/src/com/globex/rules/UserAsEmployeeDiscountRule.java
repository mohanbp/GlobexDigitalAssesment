package com.globex.rules;

import com.globex.entities.Product;
import com.globex.entities.User;
import com.globex.enums.UserTypeEnum;

public class UserAsEmployeeDiscountRule implements IDiscountRule {

	private double discountPercentage = 0.3;

	public boolean ruleExecutonStatus;

	@Override
	public Double calculateDiscount(User user, Product product) {
		Double discountedValue = 0.0;
		if (user.getUserType() == UserTypeEnum.USER_TYPE_EMPLOYEE) {
			ruleExecutonStatus = true;
			discountedValue = product.getPrice() - product.getPrice() * discountPercentage;
		}
		return discountedValue;
	}

	public boolean isRuleExecuted() {
		return ruleExecutonStatus;
	}

}
